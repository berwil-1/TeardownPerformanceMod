#include "umf/umf_meta.lua"

-- Constants
local debug = false;
local abs = math.abs;
local min, max = Vec(-math.huge, -math.huge, -math.huge), Vec(math.huge, math.huge, math.huge);
local functions = {
	bodies = {},
	shapes = {}
};
local statics = {};

-- FPS counter
local framesPerSecond = 0;
local tickIterations = 0;
local tickTotalTime = 0;

-- Other
local hideHud = false;
SetBool("savegame.mod.performance.launch", true);

-- Debris cleaner
local debrisSize = GetInt("savegame.mod.performance.debris_size");


-- Turn off all lights in the world to minimize light ray tracing.
local function disableLight(shape)
	local lights = GetShapeLights(shape);
	for j = 1, #lights do
		SetLightEnabled(lights[j], false);
	end
end
-- Remove objects that are smaller then threshold (times tick time exponentially).
local function destroyObjects(body)
	local min, max = GetBodyBounds(body);
	local size = (0.00085 * math.exp(1) ^ (260 * GetTimeStep())) * debrisSize;
	if (MakeVector(min) - MakeVector(max)):Volume() < size and GetBodyMass(body) < size then
		Delete(body);
	end
end
-- If all body shapes are not near the player then lock that body, otherwise unlock it.
local function dynamicObjects(body)
	local shapes = GetBodyShapes(body);
	local min, max = GetBodyBounds(body);

	local distance = math.huge;
	for i = 1, #shapes do
		distance = math.min(MakeVector(GetShapeWorldTransform(shapes[i]).pos):Distance(MakeVector(GetPlayerPos())), distance);
	end

	if distance > 15 then
		local velocity = GetBodyVelocity(body);
		if IsBodyDynamic(body) and (abs(velocity[1]) + abs(velocity[2]) + abs(velocity[3])) <= 0 then
			if debug then
				DrawBodyOutline(body, 1, 0, 0, 1);
			end
			SetBodyDynamic(body, false);
		end
	elseif not IsBodyDynamic(body) and (MakeVector(min) - MakeVector(max)):Volume() < 64000 then
		if debug then
			DrawBodyOutline(body, 0, 1, 0, 1);
		end
		SetBodyDynamic(body, true);
		SetBodyVelocity(Vec(0, 0, 0));
	end
end

local function callFunctions()
	-- Ignore static objects from the start (such as the world).
	for i = 1, #statics do
		QueryRejectBody(statics[i]);
	end
	local bodies = QueryAabbBodies(min, max);
	local shapes = QueryAabbShapes(min, max);

	-- Iterate over all functions and call them.
	for i = 1, #functions["bodies"] do
		for j = 1, #bodies do
			local body = bodies[j];
			if IsBodyBroken(body) then
				functions["bodies"][i](body);
			end
		end
	end
	for i = 1, #functions["shapes"] do
		for j = 1, #shapes do
			local shape = shapes[j];
			functions["shapes"][i](shape);
		end
	end
end


local fps = GetBool("savegame.mod.performance.fps");
local light = GetBool("savegame.mod.performance.light");
local debris = GetBool("savegame.mod.performance.debris");
local dynamic = GetBool("savegame.mod.performance.dynamic");

QueryRequire("physical static");
statics = QueryAabbBodies(min, max);

if light then
	functions["shapes"][#functions["shapes"] + 1] = disableLight;
	callFunctions();
	functions["shapes"] = {};
end
if debris then
	functions["bodies"][#functions["bodies"] + 1] = destroyObjects;
end
if dynamic then
	functions["bodies"][#functions["bodies"] + 1] = dynamicObjects;
end
-- Draws the frames per second counter.
hook.add("base.draw", "performance.draw", function()
	-- Draw static bodies.
	if debug then
		DebugWatch("fpsEnabled", fps)
		DebugWatch("lightEnabled", light)

		for i = 1, #statics do
			DrawBodyOutline(statics[i], 0, 0, 1, 1);
		end
	end
	
	if fps then
		UiPush();
			UiColor(-(1 / 15) * framesPerSecond + 4, (1 / 15) * framesPerSecond - 2, 0, 1);
			UiAlign("top left");
			UiFont("regular.ttf", 16);
			UiTranslate(UiWidth() - 40, 10);
			UiText(framesPerSecond);
		UiPop();
	end
end)


hook.add("base.tick", "performance.tick", function(dt)
	if InputDown("b") then
		if InputPressed("1") then
			hideHud = not hideHud;
		end
	elseif InputPressed("esc") then
		hideHud = false;
	end

	tickIterations = tickIterations + 1;
	tickTotalTime = tickTotalTime + GetTimeStep();
	if tickTotalTime >= 1 then
		framesPerSecond = tickIterations;
		tickIterations = 0;
		tickTotalTime = 0;
	elseif tickIterations % 4 == 0 then
		callFunctions();
	end
end)

hook.add("api.shoulddraw", "performance.shoulddraw", function(a)
	if hideHud then
		return false;
	end
	return true;
end)
