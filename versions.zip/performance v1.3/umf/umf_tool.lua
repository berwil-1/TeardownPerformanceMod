#include "umf/umf_core.lua"
#include "umf/extension/tool_loader.lua"

UpdateQuickloadPatch()