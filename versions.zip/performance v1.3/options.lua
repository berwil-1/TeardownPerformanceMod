-- Constants
local fireLimit;

function resetSettings()
	SetBool("savegame.mod.performance.fps", false);
	SetBool("savegame.mod.performance.light", false);
	SetBool("savegame.mod.performance.debris", true);
	SetBool("savegame.mod.performance.dynamic", true);
	SetInt("savegame.mod.performance.debris_size", 5);
	SetInt("savegame.mod.performance.fire_limit", 100);
	SetInt("savegame.mod.performance.renderscale", 100);
end
function optionsSlider(key, default, min, max)
	UiPush();
		UiTranslate(0, -8);
		local value = (GetInt(key) - min) / (max - min);
		local width = 100;
		UiRect(width, 3);
		UiAlign("center middle");
		value = UiSlider("ui/common/dot.png", "x", value * width, 0, width) / width;
		value = math.floor(value * (max - min) + min);
		SetInt(key, value);
	UiPop();
	return value;
end
function drawButton(title, key, value)
	UiPush();
		if UiTextButton(title .. " (" .. (GetBool(key) and "enabled" or "disabled") .. ")", 320, 40) then
			SetBool(key, not GetBool(key));	
		end

		if GetBool(key) then
			UiColor(0.5, 1, 0.5);
			UiTranslate(-140, 0);
			UiImage("ui/menu/mod-active.png");
		else
			UiTranslate(-140, 0);
			UiImage("ui/menu/mod-inactive.png");
		end
	UiPop();
end


function init()
	if(GetBool("savegame.mod.performance.launch")) then
		fireLimit = GetInt("savegame.mod.performance.fire_limit");
	end
	SetBool("savegame.mod.launch", false);
end

function draw()
	local modifiedFireLimit = fireLimit ~= GetInt("savegame.mod.fire_limit");

	-- Align the content to the center.
	UiTranslate(UiCenter(), 250);
	UiAlign("center middle");
	
	-- Draw the title of the options.
	UiFont("bold.ttf", 48);
	UiText("Performance mod");
	UiTranslate(0, 100);
	UiFont("regular.ttf", 26);

	-- Draw content (sliders and buttons).
	UiPush();
		UiButtonImageBox("ui/common/box-outline-6.png", 6, 6);
		drawButton("FPS counter", "savegame.mod.performance.fps");
		UiTranslate(0, 60);
		drawButton("Light disabler", "savegame.mod.performance.light");
		UiTranslate(0, 60);
		drawButton("Debris cleaner", "savegame.mod.performance.debris");
		UiTranslate(0, 60);
		drawButton("Dynamic debris", "savegame.mod.performance.dynamic");

		UiPush();
			UiTranslate(-100, 60);
			UiText("Debris size");
			UiAlign("left");
			UiTranslate(110, 8);
			local value = optionsSlider("savegame.mod.performance.debris_size", 10, 0, 100);
			UiTranslate(120, 0);
			UiText(value);
		UiPop();

		--UiTranslate(4, 60);

		-- UiPush();
		-- 	if modifiedFireLimit then UiColor(1, 0, 0); end
		-- 	UiTranslate(modifiedFireLimit and -200 or -100, 60);
		-- 	UiText(modifiedFireLimit and "Fire limit (restart needed)" or "Fire limit");
		-- 	UiAlign("left");
		-- 	UiTranslate(modifiedFireLimit and 200 or 100, 8);
		-- 	local value = optionsSlider("savegame.mod.fire_limit", 100, 0, 200);
		-- 	UiTranslate(120, 0);
		-- 	UiText(value);
		-- UiPop();

		--UiTranslate(4, 60);

		-- UiPush();
		-- 	UiTranslate(-100, 60);
		-- 	UiText("Render scale");
		-- 	UiAlign("left");
		-- 	UiTranslate(100, 8);
		-- 	local value = optionsSlider("savegame.mod.renderscale", 75, 1, 200);
		-- 	UiTranslate(120, 0);
		-- 	UiText(value);
		-- UiPop();

		UiTranslate(-120, 150);
		if UiTextButton("Close", 80, 40) or InputPressed("esc") then
			SetInt("options.gfx.renderscale", math.max(GetInt("savegame.mod.performance.renderscale"), 1));
			Menu();
		end
		UiTranslate(240, 0);
		if UiTextButton("Reset", 80, 40) then
			resetSettings();
		end
	UiPop();
end

