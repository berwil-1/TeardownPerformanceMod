# TeardownPerformanceMod
The first official mod that made it possible to run at 60 FPS under heavy load.
