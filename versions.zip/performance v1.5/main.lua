-- #include "../developer.lua"
#include "umf/umf_3d.lua"

-- TODO:
-- An option to hide the tool and all other UI elements. This can be done easily with functions such as String("game.player.tool")
-- Add a fix to shaking objects when standing on them, when items collide many times FPS will drop below 30 instantly.
-- Make the slider fill to max/min even if the mouse is moved fast.

-- Information and settings
local version = 2.0
local defaultOptions = {
	counter = {
		enabled = false,
		locked = false,
		position = {0, 0},
		size = 1,
		textSize = 16,
		textColor = {1, 1, 1, 1},
		backColor = {0, 0, 0, .5},
		accuracy = 0,
		delay = 0,
		scale = false,
		frameCount = true,
		bodyCount = false,
		shapeCount = false,
		fireCount = false,
		estimate = false
	},
	controller = {
		enabled = false,
		locked = false
	},
	cleaner = {
		enabled = false,
		locked = false
	}
}
local options = HasKey("savegame.mod.options") and util.unserialize(GetString("savegame.mod.options")) or defaultOptions


-- Variables
local tick = 0
local frames = {}
local framesPerSecond = 60
local window = {
	enabled = false,
	interact = false,
	navbar = true,
	page = 1,
	pages = {
		{
			name = "counter",
			title = "STAT COUNTER",
			description = {
				"A module that tries to estimate your frame rate,",
				"this makes it easier to know if the game runs badly.",
				"Note: this is not fully accurate due to some API limits",
				"please take this into consideration before usage!"
			},
			draw = function(x0, y0, x1, y1)
				-- Account for navbar size.
				UiAlign("left")
				UiTranslate(x0, 0)

				Draw counter full-size preview background
				UiPush()
					UiTranslate(1080, 0)
					UiColor(options.counter.backColor[1], options.counter.backColor[2], options.counter.backColor[3], options.counter.backColor[4])
					UiRect(600, y1)

					UiColor(options.counter.textColor[1], options.counter.textColor[2], options.counter.textColor[3], options.counter.textColor[4])

					UiPush()
						UiAlign("left middle")
						UiTranslate(50, y1 / 2)
						UiFont("bold.ttf", 36)
						UiText("60")
					UiPop()

					UiPush()
						UiAlign("right")
						UiTranslate(600, y1 / 2)
						UiFont("bold.ttf", 18)
						UiText("FPS")
					UiPop()
				UiPop()

				-- Draw setting elements
				UiWindow(1320 - x0, y1, false)
				UiPush()
					UiTranslate(30, 30)
					UiFont("bold.ttf", 18)

					-- Left side elements
					UiPush()
						-- Button text
						UiPush()
							UiColor(1, 1, 1, 1)
							UiAlign("center middle")

							if UiTextedButton(options.counter.enabled and "ENABLED" or "DISABLED", "center middle", 240, 60, options.counter.enabled and {.1, 1, .1, .2} or {1, .1, .1, .2}, {1, 1, 1, 1}) then options.counter.enabled = not options.counter.enabled end
							UiTranslate(240, 0)
							UiTextedButton("RESET", "center middle", 240, 60, {1, .1, .1, .2}, {1, 1, 1, 1})
						UiPop()

						-- Alignment window
						UiTranslate(0, 90)
						UiColor(.1, .1, .1, .2)
						UiRect(UiCenter() - 60, 108 / 192 * (UiCenter() - 60))
						UiPush()
							--UiTranslate((UiCenter() - 60) / 1920 * options.counter.position[1], (108 / 192 * (UiCenter() - 60)) / 1080 * options.counter.position[2])
							UiTranslate(420 / 1920 * options.counter.position[1], (270 - y1 / 10) / 1080 * options.counter.position[2])
							UiColor(.1, .1, .1, .2)
							UiRect(60, y1 / 10)
						UiPop()
						
						-- Alignment buttons
						UiTranslate(0, 108 / 192 * (UiCenter() - 60))
						UiPush()
							local buttonPositions = {{0, 0}, {x1 / 2, 0}, {x1, 0}, {0, y1 / 2}, {x1, y1 / 2}, {0, y1}, {x1 / 2, y1}, {x1, y1}}
							UiFont("bold.ttf", 16)

							for buttonIteration = 1, 8 do
								if UiTextedButton(buttonIteration, "center middle", 60, 60, {.1, .1, .1, .2}, {1, 1, 1, 1}) then
									options.counter.position = buttonPositions[buttonIteration]
								end
								UiTranslate(60, 0)
							end
						UiPop()

						-- Background color picker
						UiTranslate(0, 90)
						UiPush()
							UiColor(.1, .1, .1, .5)
							UiRect(480, 30)

							UiAlign("center middle")
							UiTranslate(240, 15)
							UiColor(1, 1, 1, 1)
							UiText("BACKGROUND COLOR")
						UiPop()
						UiTranslate(0, 30)
						for sliderIteration = 1, 3 do
							UiPush()
								options.counter.backColor[sliderIteration] = Round(UiColoredSlider(options.counter.backColor[sliderIteration], 0, 1, 480, 20, {sliderIteration == 1 and 1 or 0, sliderIteration == 2 and 1 or 0, sliderIteration == 3 and 1 or 0, .2}, {.1, .1, .1, .5}), 1, .05)
							UiPop()
							UiTranslate(0, 20)
						end

						-- Text color picker
						UiTranslate(0, 30)
						UiPush()
							UiColor(.1, .1, .1, .5)
							UiRect(480, 30)

							UiAlign("center middle")
							UiTranslate(240, 15)
							UiColor(1, 1, 1, 1)
							UiText("TEXT COLOR")
						UiPop()
						UiTranslate(0, 30)
						for sliderIteration = 1, 3 do
							UiPush()
								options.counter.textColor[sliderIteration] = Round(UiColoredSlider(options.counter.textColor[sliderIteration], 0, 1, 480, 20, {sliderIteration == 1 and 1 or 0, sliderIteration == 2 and 1 or 0, sliderIteration == 3 and 1 or 0, .2}, {.1, .1, .1, .5}), 1, .05)
							UiPop()
							UiTranslate(0, 20)
						end
					UiPop()

					-- Right side elements
					UiPush()
						UiTranslate(540, 0)

						-- Delay slider
						UiPush()
							UiColor(.1, .1, .1, .5)
							UiRect(480, 30)

							UiAlign("center middle")
							UiTranslate(240, 15)
							UiColor(1, 1, 1, 1)
							UiText("DELAY")
						UiPop()
						UiTranslate(0, 30)
						UiPush()
							options.counter.delay = Round(UiColoredSlider(options.counter.delay, 0, 60, 480, 60, {.1, .1, .1, .2}, {.1, .1, .1, .2}))
						UiPop()
						UiTranslate(0, 90)

						-- Extra modification buttons
						if UiTextedButton(options.counter.backColor[4] == 0.5 and "HIDE BACKGROUND" or "SHOW BACKGROUND", "center middle", 480, 60, {.1, .1, .1, .2}, {1, 1, 1, 1}) then
							options.counter.backColor[4] = options.counter.backColor[4] == .5 and 0 or 0.5
						end

						UiTranslate(0, 90)
						if UiTextedButton(options.counter.frameCount and "HIDE FRAME COUNT" or "SHOW FRAME COUNT", "center middle", 480, 60, {.1, .1, .1, .2}, {1, 1, 1, 1}) then
							options.counter.frameCount = not options.counter.frameCount
						end

						UiTranslate(0, 90)						
						if UiTextedButton(options.counter.bodyCount and "HIDE BODY COUNT" or "SHOW BODY COUNT", "center middle", 480, 60, {.1, .1, .1, .2}, {1, 1, 1, 1}) then
							options.counter.bodyCount = not options.counter.bodyCount
						end

						UiTranslate(0, 90)
						if UiTextedButton(options.counter.shapeCount and "HIDE SHAPE COUNT" or "SHOW SHAPE COUNT", "center middle", 480, 60, {.1, .1, .1, .2}, {1, 1, 1, 1}) then
							options.counter.shapeCount = not options.counter.shapeCount
						end

						UiTranslate(0, 90)
						if UiTextedButton(options.counter.fireCount and "HIDE FIRE COUNT" or "SHOW FIRE COUNT", "center middle", 480, 60, {.1, .1, .1, .2}, {1, 1, 1, 1}) then
							options.counter.fireCount = not options.counter.fireCount
						end

						UiTranslate(0, 90)
						if UiTextedButton(options.counter.accuracy == 0 and "MORE ACCURACY" or "LESS ACCURACY", "center middle", 480, 60, {.1, .1, .1, .2}, {1, 1, 1, 1}) then
							options.counter.accuracy = options.counter.accuracy == 2 and 0 or 2
						end
					UiPop()
				UiPop()
			end
		},
		{
			name = "controller",
			title = "LIGHT CONTROLLER",
			draw = function(x0, y0, x1, y1)
				-- Account for navbar size.
				UiAlign("left")
				UiTranslate(x0, 0)

				-- Draw setting elements
				UiWindow(1320 - x0, y1, false)
				UiPush()
					UiTranslate(30, 30)
					UiFont("bold.ttf", 18)

					-- Left side elements
					UiPush()
						-- Button text
						UiPush()
							UiColor(1, 1, 1, 1)
							UiAlign("center middle")

							if UiTextedButton(options.controller.enabled and "ENABLED" or "DISABLED", "center middle", 240, 60, options.controller.enabled and {.1, 1, .1, .2} or {1, .1, .1, .2}, {1, 1, 1, 1}) then options.controller.enabled = not options.controller.enabled end
							UiTranslate(240, 0)
							UiTextedButton("RESET", "center middle", 240, 60, {1, .1, .1, .2}, {1, 1, 1, 1})
						UiPop()
					UiPop()
				UiPop()
			end
		},
		{
			name = "cleaner",
			title = "DEBRIS CLEANER",
			draw = function(x0, y0, x1, y1)
				-- Account for navbar size.
				UiAlign("left")
				UiTranslate(x0, 0)

				-- Draw setting elements
				UiWindow(1320 - x0, y1, false)
				UiPush()
					UiTranslate(30, 30)
					UiFont("bold.ttf", 18)

					-- Left side elements
					UiPush()
						-- Button text
						UiPush()
							UiColor(1, 1, 1, 1)
							UiAlign("center middle")

							if UiTextedButton(options.cleaner.enabled and "ENABLED" or "DISABLED", "center middle", 240, 60, options.cleaner.enabled and {.1, 1, .1, .2} or {1, .1, .1, .2}, {1, 1, 1, 1}) then options.cleaner.enabled = not options.cleaner.enabled end
							UiTranslate(240, 0)
							UiTextedButton("RESET", "center middle", 240, 60, {1, .1, .1, .2}, {1, 1, 1, 1})
						UiPop()
					UiPop()
				UiPop()
			end
		}
	}
}


-- Init event call, executed on level load
hook.add("base.init", "performance.init", function()
	local bodies = GetBodies()

	-- Debugger
	if debugger and debuggerState == "game" then
		DebugPrint("--------------------------- PERFORMANCE MOD " .. version .. " ---------------------------")
		DebugPrint("If you see this notification you should contact the performance mod maintainer.")
		DebugPrint("This can be done via Discord, Reddit or Twitter.")
		DebugPrint("Discord: CoolJWB#5847 | Reddit: CoolJWB | Twitter: CoolJWB")
		DebugPrint("Level: " .. GetString("game.levelid"))
		DebugPrint("Depth: " .. GetWaterLevel())
	end

	if not HasKey("savegame.mod.version") then
		ClearKey("savegame.mod")
		SetFloat("savegame.mod.version", version)
	end

	for bodyIteration = 1, #bodies do
		local body = bodies[bodyIteration]
		local shapes = GetBodyShapes(body)
		local bodyTransform = GetBodyTransform(body)

		for shapeIteration = 1, #shapes do
			local shape = shapes[shapeIteration]

			-- Lights controller
			if options.controller[1] then
				local lights = GetShapeLights(shape)
				
				for lightIteration = 1, #lights do
					local light = lights[lightIteration]
					SetLightEnabled(light, false)
				end
			end
		end

		-- Move entire level down, used to disable shadows
		-- if options[4] then
		-- 	SetBodyTransform(body, Transform(VecSub(bodyTransform.pos, Vec(0, 22, 0)), bodyTransform.rot))
		-- end
	end
end)

hook.add("base.draw", "performance.draw", function()
	local x0, y0, x1, y1 = UiSafeMargins()
	
	-- Draw the performance window
	if window.enabled then
		if window.interact then
			UiMakeInteractive()
		end

		UiPush()
			SetBool("hud.aimdot", false)
			UiWindow(x1 - x0, y1 - y0, true)

			-- UiColor(0, 0, 0, .95)
			-- UiRect(x1, y1)

			UiAlign("center middle")
			UiColor(1, 1, 1, 1)

			if window.navbar then
				UiPush()
					UiPush()
						UiAlign("left")
						UiColor(.1, .1, .1, .2)
						UiRect(240, y1)
						x0 = x0 + 240
					UiPop()

					for pageIteration = 1, #window.pages do
						local pageName = window.pages[pageIteration].name
						local pageOptions = options[pageName]
						local textColor = pageOptions.locked and {1, .9, .9} or (pageOptions.enabled and {.9, 1, .9} or {1, .95, .9})

						--UiTranslate(0, 30)
						UiFont("bold.ttf", 18)
						
						-- UiColor(textColor[1], textColor[2], textColor[3])
						-- UiButtonHoverColor(1, 1, 1, .5)

						if UiTextedButton(window.pages[pageIteration].title, "center middle", 240, 60, {0, 0, 0, 0}, {1, 1, 1}) then
							window.page = pageIteration
						end

						if window.page == pageIteration then
							UiPush()
								UiAlign("left")
								UiColor(1, 1, 1, .1)
								UiRect(240, 60)
							UiPop()
						end
						
						UiTranslate(0, 60)
					end
				UiPop()
			end

			UiPush()
				window.pages[window.page].draw(x0, y0, x1, y1)
			UiPop()
		UiPop()
	else
		-- Draw the information counter
		if options.counter.enabled then
			DrawCounter(0, 0, 1)
		end
	end
end)

hook.add("base.tick", "performance.tick", function(dt)
	-- Debugger for developer
	if debugger and debuggerState == "game" then
		DebugWatch("DeltaTime", dt)
		DebugWatch("Page", window.page)
	end

	-- Open the performance window.
	if InputPressed("p") then
		window.enabled = not window.enabled
		SetString("savegame.mod.options", util.serialize(options))
		if InputDown("alt") then
			window.interact = window.enabled
		else
			window.interact = false
		end
	end
	-- if InputDown("alt") and InputPressed("p") then
	-- 	window.enabled = not window.enabled
	-- 	window.interact = window.enabled
	-- elseif InputPressed("p") then
	-- 	window.enabled = not window.enabled
	-- 	window.interact = false
	-- end

	-- Average the FPS values
	if tick % options.counter.delay == 0 then
		framesPerSecond = 0
		for iteration = 1, #frames do
			framesPerSecond = framesPerSecond + frames[iteration]
		end
		framesPerSecond = framesPerSecond / 60
	end

	-- Modify the variables to fit the current data
	frames[tick % 60 + 1] = 1 / dt
	tick = tick + 1
end)

hook.add("base.update", "performance.update", function(dt)
	
end)


-- Global functions
	function GetBodies()
		return QueryAabbBodies(Vec(-math.huge, -math.huge, -math.huge),Vec(math.huge, math.huge, math.huge))
	end
	function GetBodyCount()
		return #QueryAabbBodies(Vec(-math.huge, -math.huge, -math.huge),Vec(math.huge, math.huge, math.huge))
	end

	function GetShapes()
		return QueryAabbShapes(Vec(-math.huge, -math.huge, -math.huge), Vec(math.huge, math.huge, math.huge))
	end
	function GetShapeCount()
		return #QueryAabbShapes(Vec(-math.huge, -math.huge, -math.huge), Vec(math.huge, math.huge, math.huge))
	end

-- Mathematical functions
	function Round(value, decimals, overflow)
		decimals = decimals or 0
		overflow = overflow or .5
		return math.floor((value + overflow) * 10 ^ decimals) / 10 ^ decimals
	end

-- UI functions
	function UiDrawLine(dx, dy, r, g, b, a)
		UiPush()
			UiRotate(math.atan2(-dy, dx) * 180 / math.pi)
			UiRect((dx * dx + dy * dy) ^ .5, 1)
		UiPop()
	end

	function UiEmptyButton(w, h, backColor)
		UiAlign("left")

		local info = {UiIsMouseInRect(w, h), InputPressed("lmb"), InputDown("lmb")}
		local colorOffset = (info[1] and info[3]) and .1 or 0

		-- Button background
		UiPush()
			UiColor(backColor[1] - colorOffset, backColor[2] - colorOffset, backColor[3] - colorOffset, backColor[4] ~= nil and backColor[4] or 1)
			UiRect(w, h)
		UiPop()

		return info
	end

	function UiTextedButton(text, align, w, h, backColor, textColor)
		local info = UiEmptyButton(w, h, backColor)
		local colorOffset = (info[1] and info[3]) and .1 or 0

		-- Button text
		UiPush()
			UiTranslate(w / 2 + ((info[1] and info[3]) and 2 or 0), h / 2 + ((info[1] and info[3]) and 2 or 0))
			UiAlign(align)
			UiColor(textColor[1] + colorOffset, textColor[2] + colorOffset, textColor[3] + colorOffset, textColor[4] ~= nil and textColor[4] or 1)
			UiText(text)
		UiPop()

		return info[1] and info[2], info[1] and info[3]
	end

	function UiColoredSlider(value, rangeMin, rangeMax, w, h, backColor, sliderColor)
		local info = {UiIsMouseInRect(w, h), InputPressed("lmb"), InputDown("lmb")}
		
		UiPush()
			-- Slider background
			UiAlign("left")
			UiColor(backColor[1], backColor[2], backColor[3], backColor[4] ~= nil and backColor[4] or 1)
			UiRect(w, h)
		UiPop()

		-- Slider button
		local valueWidth = w / rangeMax
		local widthValue = rangeMax / w
		--local deltaRange = rangeMax - rangeMin

		local x = (info[1] and info[3]) and UiGetMousePos() or (valueWidth * value)

		--UiAlign("center middle")
		--UiTranslate(x, 0)
		local slider =  UiEmptyButton(x, h, sliderColor)

		return widthValue * x
	end


-- Counter functions
	function GetFrameCount()
		local accuracy = math.pow(10, framesPerSecond >= 100 and math.max(options.counter.accuracy - 1, 0) or options.counter.accuracy)
		return math.floor(framesPerSecond * accuracy) / accuracy
	end

	function DrawCounter(x, y, scale)
		UiPush()
			local color = options.counter.textColor
			local xAlignments = {"left", "center", "right"}
			local yAlignments = {"top", "middle", "bottom"}
			local xAlignment = 2 * options.counter.position[1] / UiWidth()
			local yAlignment = 2 * options.counter.position[2] / UiHeight()

			local enabledCounts = 0
			local counts = {{options.counter.frameCount, GetFrameCount(), "FPS"}, {options.counter.bodyCount, GetBodyCount(), "BOD"}, {options.counter.shapeCount, GetShapeCount(), "SHA"}, {options.counter.fireCount, GetFireCount(), "FIR"}}
			for enabledCountsIteration = 1, #counts do
				enabledCounts = enabledCounts + (counts[enabledCountsIteration][1] and 1 or 0)
			end

			-- Make the color scale to the current FPS
			if options.counter.scale then
				color = visual.hslrgb(math.min(math.max(framesPerSecond, 30) / 60 - .5, .5), 1, .5)
			end

			-- Draw the counter background
			local backgroundSize = 15 * enabledCounts * scale + (enabledCounts > 0 and 5 or 0) * scale
			UiAlign(xAlignments[xAlignment + 1] .. yAlignments[yAlignment + 1])
			UiTranslate(options.counter.position[1] + x, options.counter.position[2] + y)
			UiColor(options.counter.backColor[1], options.counter.backColor[2], options.counter.backColor[3], options.counter.backColor[4])
			UiRect(60 * scale, backgroundSize)

			-- Configure counter text sizes and color
			UiAlign("left middle")
			UiTranslate(-30 * xAlignment * scale, -backgroundSize * (yAlignment / 2) + 10 * options.counter.size)
			UiFont("bold.ttf", options.counter.textSize * scale)
			UiColor(color[1], color[2], color[3])

			for countIteration = 1, #counts do
				local count = counts[countIteration]

				if count[1] then
					UiPush()
						UiFont("bold.ttf", options.counter.textSize * scale - 4 * math.floor(count[2] / 10000))
						UiText(count[2])

						UiAlign("right")
						UiTranslate(60 * scale, 0)
						UiFont("bold.ttf", 8 * scale)
						UiText(count[3])
					UiPop()
					UiTranslate(0, 15 * scale)
				end
			end
		UiPop()
	end


-- Water functions
	function GetWaterLevel()
		-- Get the water depth by doing a bunch of tests all over the map.
		-- TODO: Make this find the bounds of the map.

		local depth = -2
		for x = -300, 300, 5 do
			for z = -300, 300, 5 do
				local wet, localDepth = IsPointInWater(Vec(x, depth, z))
				depth = wet and localDepth or depth
			end
		end
		return depth
	end
	function DrawWater(waterLevel)
		-- Draw the water at water level
		
		DrawSprite(LoadSprite("assets/img/water.png"), Transform(Vec(0, -22, 0), QuatEuler(90, 0, 0)), 300, 300, 1, 1, 1, 1, true, false)
	end
	function SimulateWaterPhysics(waterLevel)
		-- A method that is called to simulate water physics for boats and the player

		local boats = FindVehicles("boat", true)
		for iteration = 1, #boats do
			local boat = GetVehicleBody(boats[iteration])
			SetBodyDynamic(boat, false)
		end
	end