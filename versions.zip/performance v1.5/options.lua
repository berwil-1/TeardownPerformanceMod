
function draw()
	-- Draw the title of the options.
	UiFont("bold.ttf", 48)
	UiText("Performance mod")
	UiTranslate(0, 100)
	UiFont("regular.ttf", 26)
end

