#include "umf_core.lua"
#include "extension/visual.lua"

UpdateQuickloadPatch()
