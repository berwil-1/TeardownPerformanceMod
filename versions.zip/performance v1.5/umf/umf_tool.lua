#include "umf_core.lua"
#include "extension/tool_loader.lua"

UpdateQuickloadPatch()
